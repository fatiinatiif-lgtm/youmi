import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

const Color kBrand = Color(0xFF14958F);

final ValueNotifier<ThemeMode> themeNotifier =
    ValueNotifier<ThemeMode>(ThemeMode.light);

Future<void> toggleTheme() async {
  final dark = themeNotifier.value != ThemeMode.dark;
  themeNotifier.value = dark ? ThemeMode.dark : ThemeMode.light;
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('youmi_dark', dark);
  } catch (_) {}
}

ThemeData buildTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final bg = dark ? const Color(0xFF0E1514) : const Color(0xFFF3F8F7);
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: kBrand, brightness: brightness),
    scaffoldBackgroundColor: bg,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      centerTitle: true,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      height: 68,
      backgroundColor: dark ? const Color(0xFF16201F) : Colors.white,
      indicatorColor: kBrand.withAlpha(70),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  // Egypt local time. The city can later be selected in app settings.
  tz.setLocalLocation(tz.getLocation('Africa/Cairo'));
  await NotificationService.instance.initialize();
  try {
    final prefs = await SharedPreferences.getInstance();
    themeNotifier.value = (prefs.getBool('youmi_dark') ?? false)
        ? ThemeMode.dark
        : ThemeMode.light;
  } catch (_) {}
  runApp(const YoumiApp());
}

class YoumiApp extends StatelessWidget {
  const YoumiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) => MaterialApp(
        title: 'يومي',
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: messengerKey,
        locale: const Locale('ar'),
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: mode,
        home: const SplashScreen(),
      ),
    );
  }
}

class DailyTask {
  DailyTask({
    required this.id,
    required this.title,
    required this.category,
    this.startTime,
    this.endTime,
    this.isFlexible = false,
    this.repeatDaily = true,
    this.notifyStart = true,
    this.notifyEnd = true,
    this.focusMode = false,
    this.done = false,
    this.notes = '',
  });

  final String id;
  String title;
  String category;
  String? startTime;
  String? endTime;
  bool isFlexible;
  bool repeatDaily;
  bool notifyStart;
  bool notifyEnd;
  bool focusMode;
  bool done;
  String notes;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'startTime': startTime,
        'endTime': endTime,
        'isFlexible': isFlexible,
        'repeatDaily': repeatDaily,
        'notifyStart': notifyStart,
        'notifyEnd': notifyEnd,
        'focusMode': focusMode,
        'done': done,
        'notes': notes,
      };

  factory DailyTask.fromJson(Map<String, dynamic> json) => DailyTask(
        id: json['id'] as String,
        title: json['title'] as String? ?? '',
        category: json['category'] as String? ?? 'عام',
        startTime: json['startTime'] as String?,
        endTime: json['endTime'] as String?,
        isFlexible: json['isFlexible'] as bool? ?? false,
        repeatDaily: json['repeatDaily'] as bool? ?? true,
        notifyStart: json['notifyStart'] as bool? ?? true,
        notifyEnd: json['notifyEnd'] as bool? ?? true,
        focusMode: json['focusMode'] as bool? ?? false,
        done: json['done'] as bool? ?? false,
        notes: json['notes'] as String? ?? '',
      );
}

class TaskStore {
  static const _key = 'youmi_tasks_v2';

  static Future<List<DailyTask>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return defaultTasks();
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((e) => DailyTask.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return defaultTasks();
    }
  }

  static const _dayKey = 'youmi_last_day';
  static const _historyKey = 'youmi_history_v1';

  static String dayStamp(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  static Future<String?> loadLastDay() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_dayKey);
  }

  static Future<void> saveLastDay(String day) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_dayKey, day);
  }

  /// date -> [done, total]
  static Future<Map<String, List<int>>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    if (raw == null) return {};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((k, v) => MapEntry(
          k, (v as List<dynamic>).map((e) => e as int).toList()));
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveHistory(Map<String, List<int>> history) async {
    final keys = history.keys.toList()..sort();
    while (keys.length > 90) {
      history.remove(keys.removeAt(0));
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_historyKey, jsonEncode(history));
  }

  static Future<void> save(List<DailyTask> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(tasks.map((task) => task.toJson()).toList()),
    );
  }
}

List<DailyTask> defaultTasks() {
  int n = 0;
  DailyTask task(
    String title,
    String category, {
    String? start,
    String? end,
    String note = '',
  }) =>
      DailyTask(
        id: 'default_${n++}',
        title: title,
        category: category,
        startTime: start,
        endTime: end,
        // Tasks without a clock time depend on the prayer times, so they
        // stay flexible and have no automatic reminder.
        isFlexible: start == null,
        notifyStart: start != null,
        notifyEnd: end != null,
        notes: note,
      );

  const fajr = 'الفجر';
  const duha = 'الضحى';
  const dhuhr = 'الظهر';
  const asr = 'العصر';
  const maghrib = 'المغرب';
  const isha = 'العشاء';
  const night = 'الليل';

  return [
    // الفجر
    task('سنة قبل الفجر', fajr),
    task('صلاة الفجر', fajr),
    task('الورد الأساسي بالسبحة وجالسة في القبلة', fajr),
    task('المسبعات', fajr),
    task('الصلوات الدرديرية', fajr),
    task('المنظومة', fajr),
    task('صلوات الأنوار', fajr),
    task('الصلوات المباركات', fajr),
    task('مناجاة الأشواق', fajr),
    // الضحى
    task('صلاة الضحى', duha),
    task('مراجعة جزء من القرآن', duha, start: '09:00', end: '10:00'),
    task('حفظ ألفية السيرة', duha, start: '10:00', end: '11:00'),
    task('مراجعة فقه', duha, start: '11:00', note: 'حتى أذان الظهر'),
    // الظهر
    task('سنة قبل الظهر', dhuhr),
    task('صلاة الظهر', dhuhr),
    task('سنة بعد الظهر', dhuhr),
    task('المسبعات', dhuhr),
    task('الصلوات الدرديرية', dhuhr),
    task('المنظومة', dhuhr),
    task('سماع درس تصوف', dhuhr, start: '14:00', note: 'حتى أذان العصر'),
    // العصر
    task('صلاة العصر', asr),
    task('المسبعات', asr),
    task('الصلوات الدرديرية', asr),
    task('المنظومة', asr),
    task('مراجعة سورة كاملة', asr),
    // المغرب
    task('سنة قبل المغرب', maghrib),
    task('صلاة المغرب', maghrib),
    task('سنة بعد المغرب', maghrib),
    task('المسبعات', maghrib),
    task('الصلوات الدرديرية', maghrib),
    task('المنظومة', maghrib),
    task('الورد الأساسي مساءً: لا إله إلا الله 500 مرة بالسبحة وجالسة في القبلة',
        maghrib),
    task('سرد سورة المراجعة', maghrib),
    // العشاء
    task('صلاة العشاء', isha),
    task('سنة بعد العشاء', isha),
    task('المسبعات', isha),
    task('الصلوات الدرديرية', isha),
    task('المنظومة', isha),
    task('الوتر', isha),
    // الليل
    task('النوم', night, start: '21:00', end: '01:00'),
    task('مراجعة سورة أو سورتين من القرآن', night,
        start: '01:30', end: '03:30'),
    task('قيام الليل', night, start: '03:30', end: '04:30'),
    task('ورد السحر', night, start: '04:30', note: 'حتى الفجر'),
  ];
}

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    const android = AndroidInitializationSettings('ic_notification');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);
  }

  Future<void> requestPermission() async {
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
  }

  int _notificationId(String id, bool isStart) {
    return (id.hashCode & 0x3fffffff) + (isStart ? 1 : 2);
  }

  tz.TZDateTime? _nextTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) {
      return null;
    }
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(
      tz.local, now.year, now.month, now.day, hour, minute,
    );
    if (!scheduled.isAfter(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }

  Future<void> scheduleOne(
    DailyTask task, {
    required bool isStart,
    required String time,
  }) async {
    final scheduled = _nextTime(time);
    if (scheduled == null) return;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'youmi_tasks',
        'تذكيرات المهام',
        channelDescription: 'تذكيرات بداية ونهاية المهام في تطبيق يومي',
        importance: Importance.max,
        priority: Priority.high,
      ),
    );

    await plugin.zonedSchedule(
      _notificationId(task.id, isStart),
      isStart ? 'حان وقت المهمة' : 'انتهى وقت المهمة',
      task.title,
      scheduled,
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static const _testDetails = NotificationDetails(
    android: AndroidNotificationDetails(
      'youmi_tasks',
      'تذكيرات المهام',
      channelDescription: 'تذكيرات بداية ونهاية المهام في تطبيق يومي',
      importance: Importance.max,
      priority: Priority.high,
    ),
  );

  Future<void> showTestNow() async {
    await plugin.show(
      900001,
      'تجربة التنبيه',
      'التنبيهات تعمل بنجاح ✅',
      _testDetails,
    );
  }

  Future<void> scheduleTestInOneMinute() async {
    final when = tz.TZDateTime.now(tz.local).add(const Duration(minutes: 1));
    await plugin.zonedSchedule(
      900002,
      'تجربة التنبيه المجدول',
      'التنبيه المجدول يعمل بنجاح ✅',
      when,
      _testDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  Future<void> scheduleTask(DailyTask task) async {
    await cancelTask(task);
    if (task.isFlexible) return;
    if (task.notifyStart && task.startTime != null) {
      await scheduleOne(task, isStart: true, time: task.startTime!);
    }
    if (task.notifyEnd && task.endTime != null) {
      await scheduleOne(task, isStart: false, time: task.endTime!);
    }
  }

  Future<void> cancelTask(DailyTask task) async {
    await plugin.cancel(_notificationId(task.id, true));
    await plugin.cancel(_notificationId(task.id, false));
  }

  Future<void> rescheduleAll(List<DailyTask> tasks) async {
    await plugin.cancelAll();
    for (final task in tasks) {
      await scheduleTask(task);
    }
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 5),
  );

  @override
  void initState() {
    super.initState();
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const YoumiHome()),
        );
      }
    });
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xFF0CC0DF), Color(0xFFFFDE59)],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/splash.png',
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 56),
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) => ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: _controller.value,
                      minHeight: 10,
                      color: const Color(0xFF2F4170),
                      backgroundColor: Colors.white54,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class YoumiHome extends StatefulWidget {
  const YoumiHome({super.key});

  @override
  State<YoumiHome> createState() => _YoumiHomeState();
}

class _YoumiHomeState extends State<YoumiHome> with WidgetsBindingObserver {
  List<DailyTask> tasks = [];
  Map<String, List<int>> history = {};
  int confettiTick = 0;
  bool confettiBig = false;
  bool loading = true;
  int page = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !loading) {
      _rolloverIfNeeded();
    }
  }

  Future<void> _load() async {
    final loaded = await TaskStore.load();
    final hist = await TaskStore.loadHistory();
    if (!mounted) return;
    setState(() {
      tasks = loaded;
      history = hist;
      loading = false;
    });
    await _rolloverIfNeeded();
    await NotificationService.instance.requestPermission();
    await NotificationService.instance.rescheduleAll(tasks);
  }

  /// When a new day starts, every task goes back to "not done".
  /// Yesterday's result is already kept in [history].
  Future<void> _rolloverIfNeeded() async {
    final today = TaskStore.dayStamp(DateTime.now());
    final last = await TaskStore.loadLastDay();
    if (last == today) return;
    if (last != null && mounted) {
      setState(() {
        for (final t in tasks) {
          t.done = false;
        }
      });
    }
    await TaskStore.saveLastDay(today);
    await _save();
  }

  Future<void> _save() async {
    await TaskStore.save(tasks);
    history[TaskStore.dayStamp(DateTime.now())] = [completed, tasks.length];
    await TaskStore.saveHistory(history);
    if (mounted) setState(() {});
  }

  Future<void> _resetToday() async {
    setState(() {
      for (final t in tasks) {
        t.done = false;
      }
    });
    await _save();
  }

  double _ratioFor(DateTime day) {
    final e = history[TaskStore.dayStamp(day)];
    if (e == null || e[1] == 0) return 0;
    return e[0] / e[1];
  }

  bool _hasEntry(DateTime day) => history.containsKey(TaskStore.dayStamp(day));

  int get streak {
    var count = 0;
    var day = DateTime.now();
    if (_ratioFor(day) < 1) day = day.subtract(const Duration(days: 1));
    while (_hasEntry(day) && _ratioFor(day) >= 1) {
      count++;
      day = day.subtract(const Duration(days: 1));
    }
    return count;
  }

  int get completed => tasks.where((t) => t.done).length;

  Future<void> _editTask({DailyTask? task}) async {
    final title = TextEditingController(text: task?.title ?? '');
    final category = TextEditingController(text: task?.category ?? 'مهام إضافية');
    final start = TextEditingController(text: task?.startTime ?? '');
    final end = TextEditingController(text: task?.endTime ?? '');
    final notes = TextEditingController(text: task?.notes ?? '');
    bool flexible = task?.isFlexible ?? true;
    bool notifyStart = task?.notifyStart ?? true;
    bool notifyEnd = task?.notifyEnd ?? true;
    bool focus = task?.focusMode ?? false;

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: Text(task == null ? 'إضافة مهمة' : 'تعديل المهمة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'اسم المهمة'),
                ),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(labelText: 'التصنيف'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('مهمة مرنة بلا وقت ثابت'),
                  value: flexible,
                  onChanged: (v) => setDialog(() => flexible = v),
                ),
                if (!flexible) ...[
                  TextField(
                    controller: start,
                    keyboardType: TextInputType.datetime,
                    decoration: const InputDecoration(
                      labelText: 'وقت البداية (مثال 09:00)',
                    ),
                  ),
                  TextField(
                    controller: end,
                    keyboardType: TextInputType.datetime,
                    decoration: const InputDecoration(
                      labelText: 'وقت النهاية (مثال 10:00)',
                    ),
                  ),
                ],
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تذكير عند البداية'),
                  value: notifyStart,
                  onChanged: (v) => setDialog(() => notifyStart = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تذكير عند النهاية'),
                  value: notifyEnd,
                  onChanged: (v) => setDialog(() => notifyEnd = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('وضع التركيز (إعداد مستقبلي)'),
                  subtitle: const Text(
                    'سيتم ربطه بصلاحيات أندرويد في تحديث لاحق.',
                  ),
                  value: focus,
                  onChanged: (v) => setDialog(() => focus = v),
                ),
                TextField(
                  controller: notes,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'ملاحظات'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                if (title.text.trim().isEmpty) return;
                if (!flexible &&
                    start.text.trim().isNotEmpty &&
                    !_validTime(start.text.trim())) {
                  return;
                }
                if (!flexible &&
                    end.text.trim().isNotEmpty &&
                    !_validTime(end.text.trim())) {
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      setState(() {
        if (task == null) {
          tasks.add(DailyTask(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: title.text.trim(),
            category: category.text.trim().isEmpty
                ? 'مهام إضافية'
                : category.text.trim(),
            startTime: start.text.trim().isEmpty ? null : start.text.trim(),
            endTime: end.text.trim().isEmpty ? null : end.text.trim(),
            isFlexible: flexible,
            notifyStart: notifyStart,
            notifyEnd: notifyEnd,
            focusMode: focus,
            notes: notes.text.trim(),
          ));
        } else {
          task
            ..title = title.text.trim()
            ..category = category.text.trim().isEmpty
                ? 'مهام إضافية'
                : category.text.trim()
            ..startTime = start.text.trim().isEmpty ? null : start.text.trim()
            ..endTime = end.text.trim().isEmpty ? null : end.text.trim()
            ..isFlexible = flexible
            ..notifyStart = notifyStart
            ..notifyEnd = notifyEnd
            ..focusMode = focus
            ..notes = notes.text.trim();
        }
      });
      await _save();
      final changed = task ?? tasks.last;
      await NotificationService.instance.scheduleTask(changed);
    }
  }

  bool _validTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return false;
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    return h != null && m != null && h >= 0 && h <= 23 &&
        m >= 0 && m <= 59;
  }

  Future<void> _deleteTask(DailyTask task) async {
    setState(() => tasks.removeWhere((t) => t.id == task.id));
    await _save();
    await NotificationService.instance.cancelTask(task);
  }

  Future<void> _toggleDone(DailyTask task, bool value) async {
    await _rolloverIfNeeded();
    setState(() => task.done = value);
    await _save();
    if (value) _celebrate(task);
  }

  static const _taskMessages = [
    'ما شاء الله! أحسنتِ 🌟',
    'بارك الله فيكِ، تقبّل الله طاعتكِ 🤍',
    'أتممتِ المهمة، استمري يا بطلة 🌿',
    'الحمد لله، خطوة جميلة أخرى ✨',
    'جزاكِ الله خيرًا، ثبّتكِ الله 💚',
    'عمل رائع، واصلي 🎉',
  ];

  void _celebrate(DailyTask task) {
    HapticFeedback.mediumImpact();
    final sectionDone = tasks
        .where((t) => t.category == task.category)
        .every((t) => t.done);
    final allDone = tasks.isNotEmpty && tasks.every((t) => t.done);
    setState(() {
      confettiBig = allDone || sectionDone;
      confettiTick++;
    });
    if (allDone) {
      Future.delayed(const Duration(milliseconds: 1500), () {
        if (!mounted) return;
        showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
            title: const Center(
              child: Text('🏆', style: TextStyle(fontSize: 60)),
            ),
            content: const Text(
              'ما شاء الله! أتممتِ كل مهام اليوم.\n'
              'تقبّل الله منكِ وبارك فيكِ 🤍',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, height: 1.7),
            ),
            actionsAlignment: MainAxisAlignment.center,
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('الحمد لله'),
              ),
            ],
          ),
        );
      });
      return;
    }
    final message = sectionDone
        ? 'ما شاء الله! أتممتِ كل مهام قسم ${task.category} 🎉'
        : _taskMessages[Random().nextInt(_taskMessages.length)];
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 3),
          content: Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      );
  }

  Map<String, List<DailyTask>> get groupedTasks {
    final result = <String, List<DailyTask>>{};
    for (final task in tasks) {
      result.putIfAbsent(task.category, () => []).add(task);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        Scaffold(
          appBar: AppBar(
            title: const Text(
              'يومي',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            actions: [
              ValueListenableBuilder<ThemeMode>(
                valueListenable: themeNotifier,
                builder: (context, mode, _) => IconButton(
                  tooltip: 'الوضع الليلي',
                  onPressed: toggleTheme,
                  icon: Icon(
                    mode == ThemeMode.dark
                        ? Icons.light_mode_outlined
                        : Icons.dark_mode_outlined,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'السماح بالتنبيهات',
                onPressed: () async {
                  await NotificationService.instance.requestPermission();
                  if (mounted) {
                    messengerKey.currentState?.showSnackBar(
                      const SnackBar(content: Text('تم طلب صلاحية الإشعارات')),
                    );
                  }
                },
                icon: const Icon(Icons.notifications_active_outlined),
              ),
            ],
          ),
          body: IndexedStack(
            index: page,
            children: [
              _homePage(),
              _tasksPage(),
              _statsPage(),
              _settingsPage(),
            ],
          ),
          floatingActionButton: page == 1
              ? FloatingActionButton(
                  onPressed: () => _editTask(),
                  child: const Icon(Icons.add),
                )
              : null,
          bottomNavigationBar: NavigationBar(
            selectedIndex: page,
            onDestinationSelected: (value) => setState(() => page = value),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'الرئيسية',
              ),
              NavigationDestination(
                icon: Icon(Icons.checklist_outlined),
                selectedIcon: Icon(Icons.checklist),
                label: 'مهامي',
              ),
              NavigationDestination(
                icon: Icon(Icons.insights_outlined),
                selectedIcon: Icon(Icons.insights),
                label: 'إنجازاتي',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: 'الإعدادات',
              ),
            ],
          ),
        ),
        if (confettiTick > 0)
          Positioned.fill(
            child: ConfettiBurst(
              key: ValueKey(confettiTick),
              big: confettiBig,
            ),
          ),
      ],
    );
  }

  IconData _categoryIcon(String c) {
    switch (c) {
      case 'الفجر':
        return Icons.wb_twilight;
      case 'الضحى':
        return Icons.wb_sunny_outlined;
      case 'الظهر':
        return Icons.light_mode;
      case 'العصر':
        return Icons.wb_cloudy_outlined;
      case 'المغرب':
        return Icons.nights_stay_outlined;
      case 'العشاء':
        return Icons.dark_mode_outlined;
      case 'الليل':
        return Icons.bedtime_outlined;
      default:
        return Icons.label_outline;
    }
  }

  Widget _homePage() {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final ratio = tasks.isEmpty ? 0.0 : completed / tasks.length;
    final now = DateTime.now();
    final date = '${now.year}/${now.month.toString().padLeft(2, '0')}/'
        '${now.day.toString().padLeft(2, '0')}';
    final greeting = now.hour >= 4 && now.hour < 12
        ? 'صباح الخير 🌿'
        : (now.hour >= 12 && now.hour < 18 ? 'نهارك سعيد ☀️' : 'مساء الخير 🌙');

    DailyTask? firstOpen;
    for (final t in tasks) {
      if (!t.done) {
        firstOpen = t;
        break;
      }
    }
    final nextTask = firstOpen;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: LinearGradient(
              begin: Alignment.centerRight,
              end: Alignment.centerLeft,
              colors: dark
                  ? const [Color(0xFF0B5E63), Color(0xFF1B7F6B)]
                  : const [Color(0xFF0CC0DF), Color(0xFF3FC9A8)],
            ),
            boxShadow: [
              BoxShadow(
                color: kBrand.withAlpha(dark ? 40 : 80),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      date,
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      greeting,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'أنجزتِ $completed من ${tasks.length} مهمة',
                      style: const TextStyle(color: Colors.white, fontSize: 15),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              SizedBox(
                width: 96,
                height: 96,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox.expand(
                      child: CircularProgressIndicator(
                        value: ratio,
                        strokeWidth: 10,
                        strokeCap: StrokeCap.round,
                        color: Colors.white,
                        backgroundColor: Colors.white24,
                      ),
                    ),
                    Text(
                      '${(ratio * 100).round()}%',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (nextTask != null)
          YCard(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: kBrand.withAlpha(40),
                    child: Icon(_categoryIcon(nextTask.category), color: kBrand),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'المهمة التالية',
                          style: TextStyle(
                            fontSize: 12,
                            color: dark ? Colors.white60 : Colors.black54,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          nextTask.title,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (_subtitle(nextTask) != null) _subtitle(nextTask)!,
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.tonal(
                    onPressed: () => _toggleDone(nextTask, true),
                    child: const Text('تم ✓'),
                  ),
                ],
              ),
            ),
          )
        else
          const YCard(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Center(
                child: Text(
                  'أتممتِ كل مهام اليوم، ما شاء الله 🎉',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        const SizedBox(height: 6),
        _quickCard(
          icon: Icons.check_circle_outline,
          title: 'المهام المتبقية',
          value: '${tasks.where((t) => !t.done).length}',
          onTap: () => setState(() => page = 1),
        ),
        _quickCard(
          icon: Icons.add_task,
          title: 'إضافة مهمة',
          value: 'اضغطي لإضافة مهمة جديدة',
          onTap: () {
            setState(() => page = 1);
            _editTask();
          },
        ),
        const SizedBox(height: 12),
        Text(
          'تذكير: أوقات الصلاة والأذان تتغير يوميًا؛ '
          'اضبطي المهام المرتبطة بها حسب مواقيت مدينتك.',
          style: TextStyle(
            fontSize: 12,
            color: dark ? Colors.white54 : Colors.black45,
          ),
        ),
      ],
    );
  }

  Widget _quickCard({
    required IconData icon,
    required String title,
    required String value,
    required VoidCallback onTap,
  }) {
    return YCard(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: kBrand.withAlpha(40),
          child: Icon(icon, color: kBrand),
        ),
        title: Text(title),
        subtitle: Text(value),
        trailing: const Icon(Icons.chevron_left),
        onTap: onTap,
      ),
    );
  }

  Widget _tasksPage() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 90),
      children: [
        const Padding(
          padding: EdgeInsets.all(8),
          child: Text('جدول مهامي',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ),
        for (final entry in groupedTasks.entries) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 18, 6, 6),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: kBrand.withAlpha(40),
                  child: Icon(_categoryIcon(entry.key), size: 18, color: kBrand),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    entry.key,
                    style: const TextStyle(
                      color: kBrand,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
                Text(
                  '${entry.value.where((t) => t.done).length}'
                  ' / ${entry.value.length}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          for (final task in entry.value)
            YCard(
              color: task.done ? kBrand.withAlpha(28) : null,
              child: CheckboxListTile(
                value: task.done,
                onChanged: (v) => _toggleDone(task, v ?? false),
                controlAffinity: ListTileControlAffinity.leading,
                title: Text(
                  task.title,
                  style: TextStyle(
                    decoration: task.done
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                  ),
                ),
                subtitle: _subtitle(task),
                secondary: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') _editTask(task: task);
                    if (value == 'delete') _confirmDelete(task);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('تعديل')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }

  Widget? _subtitle(DailyTask task) {
    String t(String v) => '\u2066$v\u2069'; // keep digits left-to-right
    final parts = <String>[];
    if (task.startTime != null && task.endTime != null) {
      parts.add('${t(task.startTime!)} - ${t(task.endTime!)}');
    } else if (task.startTime != null) {
      parts.add('من ${t(task.startTime!)}');
    } else if (task.endTime != null) {
      parts.add('حتى ${t(task.endTime!)}');
    }
    if (task.notes.isNotEmpty) parts.add(task.notes);
    if (parts.isEmpty) return null;
    return Text(parts.join('  •  '));
  }

  Future<void> _confirmDelete(DailyTask task) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المهمة؟'),
        content: Text('هل تريدين حذف "${task.title}"؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (yes == true) await _deleteTask(task);
  }

  Widget _statsPage() {
    final ratio = tasks.isEmpty ? 0.0 : completed / tasks.length;
    const dayNames = [
      'الاثنين',
      'الثلاثاء',
      'الأربعاء',
      'الخميس',
      'الجمعة',
      'السبت',
      'الأحد',
    ];
    final today = DateTime.now();
    final days = [
      for (var i = 6; i >= 0; i--) today.subtract(Duration(days: i)),
    ];
    final withData = days.where(_hasEntry).toList();
    final average = withData.isEmpty
        ? 0.0
        : withData.map(_ratioFor).reduce((a, b) => a + b) / withData.length;
    var best = 0.0;
    for (final e in history.values) {
      if (e[1] > 0 && e[0] / e[1] > best) best = e[0] / e[1];
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('إنجازاتي',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        YCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text('$completed / ${tasks.length}',
                    style: const TextStyle(
                        fontSize: 32, fontWeight: FontWeight.bold)),
                const Text('مهام اليوم المكتملة'),
                const SizedBox(height: 14),
                LinearProgressIndicator(value: ratio, minHeight: 10),
              ],
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: _statTile(Icons.local_fire_department_outlined,
                  '$streak', 'أيام كاملة متتالية'),
            ),
            Expanded(
              child: _statTile(Icons.show_chart,
                  '${(average * 100).round()}%', 'متوسط آخر 7 أيام'),
            ),
            Expanded(
              child: _statTile(Icons.emoji_events_outlined,
                  '${(best * 100).round()}%', 'أفضل يوم'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        YCard(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('آخر 7 أيام',
                    style:
                        TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 14),
                SizedBox(
                  height: 140,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (final d in days)
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text('${(_ratioFor(d) * 100).round()}',
                                  style: const TextStyle(fontSize: 11)),
                              const SizedBox(height: 4),
                              Container(
                                width: 18,
                                height: 6 + 80 * _ratioFor(d),
                                decoration: BoxDecoration(
                                  color: _hasEntry(d)
                                      ? kBrand
                                      : Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(dayNames[d.weekday - 1],
                                  style: const TextStyle(fontSize: 9)),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        YCard(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('حسب القسم اليوم',
                    style:
                        TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                for (final entry in groupedTasks.entries)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(entry.key)),
                            Text(
                              '${entry.value.where((t) => t.done).length}'
                              ' / ${entry.value.length}',
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(
                          value: entry.value.isEmpty
                              ? 0
                              : entry.value.where((t) => t.done).length /
                                  entry.value.length,
                          minHeight: 7,
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text('تُعاد المهام تلقائيًا غير مكتملة مع بداية كل يوم جديد، '
            'وتُحفظ نتيجة كل يوم هنا.'),
      ],
    );
  }

  Widget _statTile(IconData icon, String value, String label) {
    return YCard(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        child: Column(
          children: [
            Icon(icon, color: kBrand),
            const SizedBox(height: 6),
            Text(value,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _settingsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('الإعدادات',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        YCard(
          child: ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('صلاحية الإشعارات'),
            subtitle: const Text('السماح للتطبيق بإرسال التذكيرات'),
            onTap: () => NotificationService.instance.requestPermission(),
          ),
        ),
        YCard(
          child: ValueListenableBuilder<ThemeMode>(
            valueListenable: themeNotifier,
            builder: (context, mode, _) => SwitchListTile(
              secondary: const Icon(Icons.dark_mode_outlined),
              title: const Text('الوضع الليلي'),
              value: mode == ThemeMode.dark,
              onChanged: (_) => toggleTheme(),
            ),
          ),
        ),
        YCard(
          child: ListTile(
            leading: const Icon(Icons.notifications_none),
            title: const Text('تجربة تنبيه الآن'),
            subtitle: const Text('يظهر تنبيه فوري للتأكد من الصلاحية'),
            onTap: () async {
              await NotificationService.instance.requestPermission();
              await NotificationService.instance.showTestNow();
            },
          ),
        ),
        YCard(
          child: ListTile(
            leading: const Icon(Icons.schedule),
            title: const Text('تجربة تنبيه مجدول بعد دقيقة'),
            subtitle: const Text(
              'للتأكد أن التنبيهات المجدولة تعمل (قد يتأخر قليلًا)',
            ),
            onTap: () async {
              await NotificationService.instance.requestPermission();
              await NotificationService.instance.scheduleTestInOneMinute();
              messengerKey.currentState?.showSnackBar(
                const SnackBar(
                  content: Text('تمت الجدولة، انتظري نحو دقيقة'),
                ),
              );
            },
          ),
        ),
        YCard(
          child: ListTile(
            leading: const Icon(Icons.restart_alt),
            title: const Text('إعادة ضبط مهام اليوم'),
            subtitle: const Text('تحويل كل المهام إلى غير مكتملة الآن'),
            onTap: () async {
              await _resetToday();
              messengerKey.currentState?.showSnackBar(
                const SnackBar(content: Text('تمت إعادة ضبط مهام اليوم')),
              );
            },
          ),
        ),
        const YCard(
          child: ListTile(
            leading: Icon(Icons.location_city_outlined),
            title: Text('المدينة'),
            subtitle: Text('الفيوم - مصر (إعداد المنطقة الزمنية الحالي)'),
          ),
        ),
        const YCard(
          child: ListTile(
            leading: Icon(Icons.do_not_disturb_on_outlined),
            title: Text('وضع التركيز'),
            subtitle: Text(
              'إعداد الواجهة موجود، لكن التحكم الفعلي في وضع عدم الإزعاج '
              'وحظر التطبيقات يحتاج تكامل أندرويد إضافيًا.',
            ),
          ),
        ),
        const YCard(
          child: ListTile(
            leading: Icon(Icons.backup_outlined),
            title: Text('النسخ الاحتياطي'),
            subtitle: Text('ميزة النسخ الاحتياطي السحابي ستضاف لاحقًا.'),
          ),
        ),
      ],
    );
  }
}


class YCard extends StatelessWidget {
  const YCard({super.key, required this.child, this.color});

  final Widget child;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Card(
      elevation: 0,
      clipBehavior: Clip.antiAlias,
      color: color ?? (dark ? const Color(0xFF18221F) : Colors.white),
      margin: const EdgeInsets.symmetric(vertical: 5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: dark ? Colors.white10 : Colors.black.withAlpha(18),
        ),
      ),
      child: child,
    );
  }
}

class _Piece {
  _Piece({
    required this.angle,
    required this.speed,
    required this.size,
    required this.spin,
    required this.color,
    required this.round,
  });

  final double angle;
  final double speed;
  final double size;
  final double spin;
  final Color color;
  final bool round;
}

class ConfettiBurst extends StatefulWidget {
  const ConfettiBurst({super.key, this.big = false});

  final bool big;

  @override
  State<ConfettiBurst> createState() => _ConfettiBurstState();
}

class _ConfettiBurstState extends State<ConfettiBurst>
    with SingleTickerProviderStateMixin {
  static const _colors = [
    Color(0xFF0CC0DF),
    Color(0xFFFFDE59),
    Color(0xFFFF77C4),
    Color(0xFF2F4170),
    Color(0xFF7ED957),
    Color(0xFFFF9F43),
  ];

  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  );
  late final List<_Piece> _pieces;

  @override
  void initState() {
    super.initState();
    final r = Random();
    final count = widget.big ? 160 : 70;
    _pieces = List.generate(
      count,
      (_) => _Piece(
        angle: -pi * (0.12 + r.nextDouble() * 0.76),
        speed: 350 + r.nextDouble() * 700,
        size: 6 + r.nextDouble() * 7,
        spin: r.nextDouble() * 10 - 5,
        color: _colors[r.nextInt(_colors.length)],
        round: r.nextBool(),
      ),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _ConfettiPainter(_pieces, _controller.value),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.pieces, this.progress);

  final List<_Piece> pieces;
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * 2.4;
    final origin = Offset(size.width / 2, size.height * 0.78);
    final opacity = progress < 0.7 ? 1.0 : ((1 - progress) / 0.3).clamp(0.0, 1.0);
    for (final p in pieces) {
      final dx = cos(p.angle) * p.speed * t;
      final dy = sin(p.angle) * p.speed * t + 0.5 * 1500 * t * t;
      final paint = Paint()
        ..color = p.color.withAlpha((opacity * 255).round());
      canvas.save();
      canvas.translate(origin.dx + dx, origin.dy + dy);
      canvas.rotate(p.spin * t);
      if (p.round) {
        canvas.drawCircle(Offset.zero, p.size / 2, paint);
      } else {
        canvas.drawRect(
          Rect.fromCenter(
            center: Offset.zero,
            width: p.size,
            height: p.size * 0.55,
          ),
          paint,
        );
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter old) =>
      old.progress != progress;
}
