import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  // Egypt local time. The city can later be selected in app settings.
  tz.setLocalLocation(tz.getLocation('Africa/Cairo'));
  await NotificationService.instance.initialize();
  runApp(const YoumiApp());
}

class YoumiApp extends StatelessWidget {
  const YoumiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'يومي',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: messengerKey,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF176B50),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF6F8F6),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF6F8F6),
          centerTitle: true,
        ),
      ),
      home: const YoumiHome(),
    );
  }
}

class DailyTask {
  DailyTask({
    required this.id,
    required this.title,
    required this.category,
    this.startTime,
    this.endTime,
    this.isFlexible = false,
    this.repeatDaily = true,
    this.notifyStart = true,
    this.notifyEnd = true,
    this.focusMode = false,
    this.done = false,
    this.notes = '',
  });

  final String id;
  String title;
  String category;
  String? startTime;
  String? endTime;
  bool isFlexible;
  bool repeatDaily;
  bool notifyStart;
  bool notifyEnd;
  bool focusMode;
  bool done;
  String notes;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'startTime': startTime,
        'endTime': endTime,
        'isFlexible': isFlexible,
        'repeatDaily': repeatDaily,
        'notifyStart': notifyStart,
        'notifyEnd': notifyEnd,
        'focusMode': focusMode,
        'done': done,
        'notes': notes,
      };

  factory DailyTask.fromJson(Map<String, dynamic> json) => DailyTask(
        id: json['id'] as String,
        title: json['title'] as String? ?? '',
        category: json['category'] as String? ?? 'عام',
        startTime: json['startTime'] as String?,
        endTime: json['endTime'] as String?,
        isFlexible: json['isFlexible'] as bool? ?? false,
        repeatDaily: json['repeatDaily'] as bool? ?? true,
        notifyStart: json['notifyStart'] as bool? ?? true,
        notifyEnd: json['notifyEnd'] as bool? ?? true,
        focusMode: json['focusMode'] as bool? ?? false,
        done: json['done'] as bool? ?? false,
        notes: json['notes'] as String? ?? '',
      );
}

class TaskStore {
  static const _key = 'youmi_tasks_v1';

  static Future<List<DailyTask>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return defaultTasks();
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((e) => DailyTask.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return defaultTasks();
    }
  }

  static Future<void> save(List<DailyTask> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(tasks.map((task) => task.toJson()).toList()),
    );
  }
}

List<DailyTask> defaultTasks() {
  int n = 0;
  DailyTask task(
    String title,
    String category, {
    String? start,
    String? end,
    bool flexible = true,
  }) =>
      DailyTask(
        id: 'default_${n++}',
        title: title,
        category: category,
        startTime: start,
        endTime: end,
        isFlexible: flexible,
        // These are starter reminders. Review the schedule and set exact
        // clock times before relying on notifications.
        notifyStart: start != null,
        notifyEnd: end != null,
      );

  return [
    task('سنة قبل الفجر', 'الصلوات'),
    task('صلاة الفجر', 'الصلوات'),
    task('الورد الأساسي بالسبحة والجلوس في القبلة', 'الأوراد'),
    task('المسبعات', 'الأوراد'),
    task('الصلوات الدرديرية', 'الأوراد'),
    task('المنظومة', 'الأوراد'),
    task('صلوات الأنوار', 'الأوراد'),
    task('الصلوات المباركات', 'الأوراد'),
    task('مناجاة الأشواق', 'الأوراد'),
    task('صلاة الضحى', 'الصلوات'),
    task('مراجعة جزء من القرآن', 'القرآن',
        start: '09:00', end: '10:00', flexible: false),
    task('حفظ ألفية السيرة', 'العلم',
        start: '10:00', end: '11:00', flexible: false),
    task('مراجعة الفقه', 'العلم'),
    task('سنة قبل الظهر', 'الصلوات'),
    task('صلاة الظهر', 'الصلوات'),
    task('سنة بعد الظهر', 'الصلوات'),
    task('المسبعات', 'الأوراد'),
    task('الصلوات الدرديرية', 'الأوراد'),
    task('المنظومة', 'الأوراد'),
    task('سماع درس التصوف', 'العلم',
        start: '14:00', end: null, flexible: false),
    task('صلاة العصر', 'الصلوات'),
    task('المسبعات', 'الأوراد'),
    task('الصلوات الدرديرية', 'الأوراد'),
    task('المنظومة', 'الأوراد'),
    task('مراجعة سورة كاملة', 'القرآن'),
    task('سنة قبل المغرب', 'الصلوات'),
    task('صلاة المغرب', 'الصلوات'),
    task('سنة بعد المغرب', 'الصلوات'),
    task('المسبعات', 'الأوراد'),
    task('الصلوات الدرديرية', 'الأوراد'),
    task('المنظومة', 'الأوراد'),
    task('الورد الأساسي مساءً: لا إله إلا الله 500 مرة', 'الأوراد'),
    task('سرد سورة المراجعة', 'القرآن'),
    task('صلاة العشاء', 'الصلوات'),
    task('سنة بعد العشاء', 'الصلوات'),
    task('المسبعات', 'الأوراد'),
    task('الصلوات الدرديرية', 'الأوراد'),
    task('المنظومة', 'الأوراد'),
    task('صلاة الوتر', 'الصلوات'),
    task('النوم', 'الراحة',
        start: '21:00', end: '01:00', flexible: false),
    task('مراجعة سورة أو سورتين', 'القرآن',
        start: '01:30', end: '03:30', flexible: false),
    task('قيام الليل', 'العبادات',
        start: '03:30', end: '04:30', flexible: false),
    task('ورد السحر', 'الأوراد',
        start: '04:30', end: null, flexible: false),
  ];
}

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);
  }

  Future<void> requestPermission() async {
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
  }

  int _notificationId(String id, bool isStart) {
    return (id.hashCode & 0x3fffffff) + (isStart ? 1 : 2);
  }

  tz.TZDateTime? _nextTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) {
      return null;
    }
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(
      tz.local, now.year, now.month, now.day, hour, minute,
    );
    if (!scheduled.isAfter(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }

  Future<void> scheduleOne(
    DailyTask task, {
    required bool isStart,
    required String time,
  }) async {
    final scheduled = _nextTime(time);
    if (scheduled == null) return;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'youmi_tasks',
        'تذكيرات المهام',
        channelDescription: 'تذكيرات بداية ونهاية المهام في تطبيق يومي',
        importance: Importance.max,
        priority: Priority.high,
      ),
    );

    await plugin.zonedSchedule(
      _notificationId(task.id, isStart),
      isStart ? 'حان وقت المهمة' : 'انتهى وقت المهمة',
      task.title,
      scheduled,
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> scheduleTask(DailyTask task) async {
    await cancelTask(task);
    if (task.isFlexible) return;
    if (task.notifyStart && task.startTime != null) {
      await scheduleOne(task, isStart: true, time: task.startTime!);
    }
    if (task.notifyEnd && task.endTime != null) {
      await scheduleOne(task, isStart: false, time: task.endTime!);
    }
  }

  Future<void> cancelTask(DailyTask task) async {
    await plugin.cancel(_notificationId(task.id, true));
    await plugin.cancel(_notificationId(task.id, false));
  }

  Future<void> rescheduleAll(List<DailyTask> tasks) async {
    for (final task in tasks) {
      await scheduleTask(task);
    }
  }
}

class YoumiHome extends StatefulWidget {
  const YoumiHome({super.key});

  @override
  State<YoumiHome> createState() => _YoumiHomeState();
}

class _YoumiHomeState extends State<YoumiHome> {
  List<DailyTask> tasks = [];
  bool loading = true;
  int page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final loaded = await TaskStore.load();
    if (!mounted) return;
    setState(() {
      tasks = loaded;
      loading = false;
    });
    await NotificationService.instance.rescheduleAll(tasks);
  }

  Future<void> _save() async {
    await TaskStore.save(tasks);
  }

  int get completed => tasks.where((t) => t.done).length;

  Future<void> _editTask({DailyTask? task}) async {
    final title = TextEditingController(text: task?.title ?? '');
    final category = TextEditingController(text: task?.category ?? 'مهام إضافية');
    final start = TextEditingController(text: task?.startTime ?? '');
    final end = TextEditingController(text: task?.endTime ?? '');
    final notes = TextEditingController(text: task?.notes ?? '');
    bool flexible = task?.isFlexible ?? true;
    bool notifyStart = task?.notifyStart ?? true;
    bool notifyEnd = task?.notifyEnd ?? true;
    bool focus = task?.focusMode ?? false;

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: Text(task == null ? 'إضافة مهمة' : 'تعديل المهمة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'اسم المهمة'),
                ),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(labelText: 'التصنيف'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('مهمة مرنة بلا وقت ثابت'),
                  value: flexible,
                  onChanged: (v) => setDialog(() => flexible = v),
                ),
                if (!flexible) ...[
                  TextField(
                    controller: start,
                    keyboardType: TextInputType.datetime,
                    decoration: const InputDecoration(
                      labelText: 'وقت البداية (مثال 09:00)',
                    ),
                  ),
                  TextField(
                    controller: end,
                    keyboardType: TextInputType.datetime,
                    decoration: const InputDecoration(
                      labelText: 'وقت النهاية (مثال 10:00)',
                    ),
                  ),
                ],
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تذكير عند البداية'),
                  value: notifyStart,
                  onChanged: (v) => setDialog(() => notifyStart = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تذكير عند النهاية'),
                  value: notifyEnd,
                  onChanged: (v) => setDialog(() => notifyEnd = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('وضع التركيز (إعداد مستقبلي)'),
                  subtitle: const Text(
                    'سيتم ربطه بصلاحيات أندرويد في تحديث لاحق.',
                  ),
                  value: focus,
                  onChanged: (v) => setDialog(() => focus = v),
                ),
                TextField(
                  controller: notes,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'ملاحظات'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                if (title.text.trim().isEmpty) return;
                if (!flexible &&
                    start.text.trim().isNotEmpty &&
                    !_validTime(start.text.trim())) {
                  return;
                }
                if (!flexible &&
                    end.text.trim().isNotEmpty &&
                    !_validTime(end.text.trim())) {
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      setState(() {
        if (task == null) {
          tasks.add(DailyTask(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: title.text.trim(),
            category: category.text.trim().isEmpty
                ? 'مهام إضافية'
                : category.text.trim(),
            startTime: start.text.trim().isEmpty ? null : start.text.trim(),
            endTime: end.text.trim().isEmpty ? null : end.text.trim(),
            isFlexible: flexible,
            notifyStart: notifyStart,
            notifyEnd: notifyEnd,
            focusMode: focus,
            notes: notes.text.trim(),
          ));
        } else {
          task
            ..title = title.text.trim()
            ..category = category.text.trim().isEmpty
                ? 'مهام إضافية'
                : category.text.trim()
            ..startTime = start.text.trim().isEmpty ? null : start.text.trim()
            ..endTime = end.text.trim().isEmpty ? null : end.text.trim()
            ..isFlexible = flexible
            ..notifyStart = notifyStart
            ..notifyEnd = notifyEnd
            ..focusMode = focus
            ..notes = notes.text.trim();
        }
      });
      await _save();
      final changed = task ?? tasks.last;
      await NotificationService.instance.scheduleTask(changed);
    }
  }

  bool _validTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return false;
    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    return h != null && m != null && h >= 0 && h <= 23 &&
        m >= 0 && m <= 59;
  }

  Future<void> _deleteTask(DailyTask task) async {
    setState(() => tasks.removeWhere((t) => t.id == task.id));
    await _save();
    await NotificationService.instance.cancelTask(task);
  }

  Future<void> _toggleDone(DailyTask task, bool value) async {
    setState(() => task.done = value);
    await _save();
  }

  Map<String, List<DailyTask>> get groupedTasks {
    final result = <String, List<DailyTask>>{};
    for (final task in tasks) {
      result.putIfAbsent(task.category, () => []).add(task);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'يومي',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            tooltip: 'السماح بالتنبيهات',
            onPressed: () async {
              await NotificationService.instance.requestPermission();
              if (mounted) {
                messengerKey.currentState?.showSnackBar(
                  const SnackBar(content: Text('تم طلب صلاحية الإشعارات')),
                );
              }
            },
            icon: const Icon(Icons.notifications_active_outlined),
          ),
        ],
      ),
      body: IndexedStack(
        index: page,
        children: [
          _homePage(),
          _tasksPage(),
          _statsPage(),
          _settingsPage(),
        ],
      ),
      floatingActionButton: page == 1
          ? FloatingActionButton(
              onPressed: () => _editTask(),
              child: const Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: page,
        onDestinationSelected: (value) => setState(() => page = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.checklist_outlined),
            selectedIcon: Icon(Icons.checklist),
            label: 'مهامي',
          ),
          NavigationDestination(
            icon: Icon(Icons.insights_outlined),
            selectedIcon: Icon(Icons.insights),
            label: 'إنجازاتي',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }

  Widget _homePage() {
    final ratio = tasks.isEmpty ? 0.0 : completed / tasks.length;
    final now = DateTime.now();
    final date = '${now.year}/${now.month.toString().padLeft(2, '0')}/'
        '${now.day.toString().padLeft(2, '0')}';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(date, textDirection: TextDirection.ltr,
            style: TextStyle(color: Colors.grey.shade700)),
        const SizedBox(height: 8),
        const Text(
          'أهلًا بكِ في يومك 🌿',
          style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إنجاز اليوم'),
                const SizedBox(height: 8),
                Text('$completed من ${tasks.length}',
                    style: const TextStyle(
                        fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                LinearProgressIndicator(value: ratio, minHeight: 9),
                const SizedBox(height: 8),
                Text('${(ratio * 100).round()}% مكتمل'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _quickCard(
          icon: Icons.check_circle_outline,
          title: 'المهام المتبقية',
          value: '${tasks.where((t) => !t.done).length}',
          onTap: () => setState(() => page = 1),
        ),
        _quickCard(
          icon: Icons.add_task,
          title: 'إضافة مهمة',
          value: 'اضغطي لإضافة مهمة جديدة',
          onTap: () {
            setState(() => page = 1);
            _editTask();
          },
        ),
        const SizedBox(height: 12),
        const Text('تذكير: أوقات الصلاة والأذان تتغير يوميًا؛ '
            'اضبطي المهام المرتبطة بها حسب مواقيت مدينتك.'),
      ],
    );
  }

  Widget _quickCard({
    required IconData icon,
    required String title,
    required String value,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF176B50)),
        title: Text(title),
        subtitle: Text(value),
        trailing: const Icon(Icons.chevron_left),
        onTap: onTap,
      ),
    );
  }

  Widget _tasksPage() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Padding(
          padding: EdgeInsets.all(8),
          child: Text('جدول مهامي',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ),
        for (final entry in groupedTasks.entries) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 18, 8, 6),
            child: Text(entry.key,
                style: const TextStyle(
                    color: Color(0xFF176B50),
                    fontWeight: FontWeight.bold,
                    fontSize: 17)),
          ),
          for (final task in entry.value)
            Card(
              child: CheckboxListTile(
                value: task.done,
                onChanged: (v) => _toggleDone(task, v ?? false),
                controlAffinity: ListTileControlAffinity.leading,
                title: Text(
                  task.title,
                  style: TextStyle(
                    decoration: task.done
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                  ),
                ),
                subtitle: Text(
                  [
                    if (task.startTime != null) task.startTime!,
                    if (task.endTime != null) task.endTime!,
                    if (task.isFlexible) 'موعد مرن',
                  ].join('  •  '),
                  textDirection: TextDirection.ltr,
                  textAlign: TextAlign.right,
                ),
                secondary: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') _editTask(task: task);
                    if (value == 'delete') _confirmDelete(task);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('تعديل')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }

  Future<void> _confirmDelete(DailyTask task) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المهمة؟'),
        content: Text('هل تريدين حذف "${task.title}"؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (yes == true) await _deleteTask(task);
  }

  Widget _statsPage() {
    final ratio = tasks.isEmpty ? 0.0 : completed / tasks.length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('إنجازاتي',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text('$completed / ${tasks.length}',
                    style: const TextStyle(
                        fontSize: 32, fontWeight: FontWeight.bold)),
                const Text('المهام المكتملة'),
                const SizedBox(height: 14),
                LinearProgressIndicator(value: ratio, minHeight: 10),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _settingsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('الإعدادات',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('صلاحية الإشعارات'),
            subtitle: const Text('السماح للتطبيق بإرسال التذكيرات'),
            onTap: () => NotificationService.instance.requestPermission(),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.location_city_outlined),
            title: Text('المدينة'),
            subtitle: Text('الفيوم - مصر (إعداد المنطقة الزمنية الحالي)'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.do_not_disturb_on_outlined),
            title: Text('وضع التركيز'),
            subtitle: Text(
              'إعداد الواجهة موجود، لكن التحكم الفعلي في وضع عدم الإزعاج '
              'وحظر التطبيقات يحتاج تكامل أندرويد إضافيًا.',
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.backup_outlined),
            title: Text('النسخ الاحتياطي'),
            subtitle: Text('ميزة النسخ الاحتياطي السحابي ستضاف لاحقًا.'),
          ),
        ),
      ],
    );
  }
}
